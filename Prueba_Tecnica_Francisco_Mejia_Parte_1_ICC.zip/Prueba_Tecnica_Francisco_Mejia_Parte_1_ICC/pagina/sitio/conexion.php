<?php
$servidor = "localhost";
$user = "root";
$pass = "";
$db = "persona";

$conex = new mysqli($servidor,$user,$pass,$db);
if ($conex->connect_errno) {
	echo "Fallo al conectar con la base de datos: " . $conex->connect_errno . ") " . $conex->connect_errno;
}
?>