CREATE DATABASE IF NOT EXISTS icc;

USE icc;

CREATE TABLE alumnos(
	id_alumnos INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL,
	apellido VARCHAR(20) NOT NULL,
	documento_identidad VARCHAR(15) NOT NULL  UNIQUE,
	fecha_nacimiento DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE docentes(
	id_docentes INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL,
	apellido VARCHAR(20) NOT NULL,
	num_contacto VARCHAR(15) NOT NULL,
	num_identificacion VARCHAR(15) NOT NULL UNIQUE,	
	especialidad VARCHAR(20)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cursos(
	id_cursos INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL,
	jornada VARCHAR(20) NOT NULL,
	sede VARCHAR(20) NOT NULL,
	fk_alumnos INT NOT NULL,
	fk_docentes INT NOT NULL,
	KEY (fk_alumnos),
	KEY (fk_docentes),
	FOREIGN KEY (fk_alumnos) REFERENCES alumnos (id_alumnos) ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (fk_docentes) REFERENCES docentes (id_docentes) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;